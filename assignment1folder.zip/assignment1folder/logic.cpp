#include "include/logic.h"

long fibbonacci(const int n) { return 0; }

int is_prime(const int n) { return 0; }

long factorial(const int n) { return 0; }

int reverse(const int n) { return 0; }