#ifndef CONSTS_H
#define CONSTS_H

const int HEIGHT = 100;
const int WIDTH = 100;
const int SHIP_COUNT = 25;

#endif /* CONSTS_H */
